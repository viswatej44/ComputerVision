import cv2
import mediapipe as mp
import time

from main import mpPose


class poseDetector():
    def __init__(self,mode=False,upBody = False,smooth = True,detectioncon = 0.5,trackcon = 0.5):

        self.mode = mode
        self.upBody = upBody
        self.smooth = smooth
        self.detectioncon = detectioncon
        self.trackcon = trackcon



        self.mpDraw = mp.solutions.drawing_utils
        self.mpPose = mp.solutions.pose
        self.pose   = mpPose.Pose(self.mode,self.upBody,self.smooth,self.detectioncon,self.trackcon)

    def findpose(self,img,draw=True):




            imgRGB =cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
            results = self.pose.process(imgRGB)

            if results.pose_landmarks:
                if draw:
                    self.mpDraw.draw_landmarks(img,self.results.pose_landmarks,self.mpPose.POSE_CONNECTIONS)

                return img

    def getPosition(self,img, draw =True):
        lmlist = []
        if self.results.pose_landmarks:
            for lm,id in enumerate(self.results.pose_landmarks.landmark):
             h,w,c = img.shape
             #print(id,lm)
             cx,cy = int(lm * w), int(lm * h)
             lmlist.append([id,cx,cy])
             if draw:

                cv2.circle(img,(cx,cy),4,(255,0,0),cv2.FILLED)
        return lmlist
    ###############===FPS



    cv2.waitKey(10)



def main():
    cap = cv2.VideoCapture('/Users/viswaboyalagunta/PycharmProjects/PE4/AiTrainer/curls.mp4')
    pTime = 0
    detctor = poseDetector()

    while True:
        success, img = cap.read()
        img = detctor.find(img)
        lmlist = detctor.findpose(img)
        print(lmlist)

        cTime = time.time()
        fps = 1 / (cTime - pTime)
        pTime = cTime
        cv2.putText(img, "FPS=", (20, 20), cv2.FONT_HERSHEY_SIMPLEX, 3, (255, 0, 0), 3)
        cv2.putText(img, str(int(fps)), (70, 90), cv2.FONT_HERSHEY_SIMPLEX, 3, (255, 0, 0), 3)

        cv2.imshow("Image", img)


if __name__ =  "__main__":
    main()